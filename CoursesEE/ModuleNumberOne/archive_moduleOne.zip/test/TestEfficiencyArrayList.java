package CoursesEE.ModuleNumberOne.test;

import CoursesEE.ModuleNumberOne.src.EfficiencyArrayList;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class TestEfficiencyArrayList {

    @Test
    public void testTestTimeAddToArrayList() throws Exception {
        int numberOfIterations = 1000;
        EfficiencyArrayList effArrayList = new EfficiencyArrayList(numberOfIterations);;
        List<Integer> arr = new ArrayList<>();

        for (int i = 0; i < numberOfIterations; i++) {
            arr.add(i);
        }
        Assert.assertEquals(arr.size(), numberOfIterations);
    }
}